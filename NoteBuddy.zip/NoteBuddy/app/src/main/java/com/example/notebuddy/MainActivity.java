package com.example.notebuddy;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

/**
*
* @author Marcus McFarlane
*/
public class MainActivity extends AppCompatActivity {

    //creates new instance for  database adapter
    DBAdapter myDB;

    /**
     * method that sets what function to be done when app is opened
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //opens database
        openDB();
        //populates listview with info from database
        populateListView();

    }

    /**
     * Closes database when app is force closed
     */
    @Override
    protected void onDestroy(){
        super.onDestroy();
        closeDB();
    }

    /**
     * Opens database
     */
    private void openDB(){
        myDB = new DBAdapter(this);
        myDB.open();
    }
    /*
    Closes database
     */
    private void closeDB(){
        myDB.close();
    }

    /**
     * Starts new writenote activity
     * @param view
     */
    public void newNote(View view) {
        Intent intent = new Intent(this, WriteNoteActivity.class);
        startActivity(intent);
    }
    /*
    appends data in database to listview
     */
    private void populateListView(){
        //creates cursor to database
        Cursor cursor = myDB.getAllRows();
        startManagingCursor(cursor);

        //creates string array of fields in table
        String[] fieldNames = new String[] {DBAdapter.KEY_TITLE, DBAdapter.KEY_NOTE};
        int[] viewID = new int[] {R.id.item_title, R.id.item_note};
        //creates cursor adapter to populate listview
        SimpleCursorAdapter simpleCursorAdapter = new SimpleCursorAdapter(this, R.layout.item_layout, cursor, fieldNames, viewID);
        ListView list = (ListView) findViewById(R.id.listView);
        list.setAdapter(simpleCursorAdapter);
    }
    public void deleteList(View view){
        myDB.deleteAll();
        populateListView();

    }
}