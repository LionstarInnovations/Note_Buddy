package com.example.notebuddy;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
*
* @author Marcus McFarlane
*/
public class WriteNoteActivity extends AppCompatActivity {
    //Creates new instance of a Database Adapter class
    private DBAdapter myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        //opens the database
        openDB();

        //creates editable text fields
        final EditText edTitle = (EditText) findViewById(R.id.etTitle);


        final EditText edNote = (EditText) findViewById(R.id.etNote);

        //initialises the button and sets on click behaviour
        Button buttonSave = (Button) findViewById(R.id.saveButton);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //reads input from text fields
                final String title = edTitle.getText().toString();
                final String note = edNote.getText().toString();

                addRecord(title, note);
                Toast.makeText(getBaseContext(), "Note Saved", Toast.LENGTH_SHORT).show();
                edTitle.setText("");
                edNote.setText("");
            }
        });

    }

    /**
     * Method to open database
     */
    private void openDB() {
        myDB = new DBAdapter(this);
        myDB.open();
    }

    /**
     * Method to add a record into the database
     * @param title
     * @param note
     */
    private void addRecord(String title, String note){
        myDB.insertRow(title, note);


    }

    /**
     * method to set function to be done when back button clicked
     */
    @Override
    public void onBackPressed(){
        super.onBackPressed();
        finish();
        //Creates intent to open main activity
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        //closes the database
        myDB.close();
    }
}

