NOTEBUDDY

What is it?
########################################################################

NoteBuddy is an alternative note taking android app.
It provides a simple interface to view and take notes as compared to the android notes app.

########################################################################


Installation
########################################################################

To install, save and unpackage the .apk file in your android device.
Accept all permissions, should be pretty straighforward!
NB: Please allow installation from unknown sources in the Security options
as this app is not licensed yet.

########################################################################


Operating Instructions
########################################################################
After installing the app. click the app icon to launch it. If no files
are written, it will display an empty menu. To create a new note, click
the new note button where a new page will be opened. After typing in
your note, click the save button and to return to the main menu click
the back button after which it will display a list with the newly
created notes.

App Features
########################################################################

The main activity of the app implements a list view to display the saved
notes. The notes are saved in a sqlite database that is queried upon
opening the app to view if there are any previous records.


Sysyem Specific Notes
########################################################################
Please be aware that this program was designed using the Marsmallow API
and therefore may not work for older APIs

Known Bugs
########################################################################
The app may crash at start at times in case of failure of database
creation. Uninstall and Reinstall the app in case it does.

Bug-Reporting and Collaborations
########################################################################
To contact the authors if you wish to improve the app, collaborate or
report bugs, please use the following email:

Marcus McFarlane: sc14mm@leeds.ac.uk
